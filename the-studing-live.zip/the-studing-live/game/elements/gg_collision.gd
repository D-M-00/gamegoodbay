extends CharacterBody2D


const SPEED = 400.0


func _physics_process(delta: float):
	var direction := Input.get_axis("ui_left", "ui_right" )
	var ddirection := Input.get_axis("ui_up", "ui_down", )

	#global_position.x = direction * SPEED * delta

	velocity.x = direction * SPEED 
	velocity.y = ddirection * SPEED

	move_and_slide()


func _on_tell_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file("res://game/улица.tscn")


func _on_tell_mveu_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file("res://game/mveu.tscn")


func _on_tell_ruskiy_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file("res://game/kabinet Russkogo.tscn")





func _on_tell_obratno_ylitsa_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file("res://game/улица.tscn")


func _on_tell_obratno_domoy_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file("res://game.tscn")


func _on_tell_obratno_mveu_body_entered(body: Node2D) -> void:
	get_tree().change_scene_to_file("res://game/mveu.tscn")
